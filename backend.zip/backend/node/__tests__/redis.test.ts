import { createClient, RedisClientType } from 'redis';
import redisClient from '../utils/redis'; // Adjust the path accordingly

// Mock the 'redis' module to avoid real Redis connections during tests
jest.mock('redis');

describe('Redis Client', () => {
  let redisMockClient: RedisClientType;

  beforeEach(() => {
    // Reset the mocks before each test
    redisMockClient = createClient();
    
    // Mock the 'connect' method to return a resolved promise
    redisMockClient.connect = jest.fn().mockResolvedValue(undefined);

    // Mock the 'on' method
    redisMockClient.on = jest.fn((event: string, callback: (...args: any[]) => void) => {
      // Simulate the 'connect' event
      if (event === 'connect') callback(); // Simulate the connect event
      // Simulate the 'error' event with a mocked error
      if (event === 'error') {
        const mockError = new Error('Redis error occurred');
        callback(mockError); // Simulate passing error to callback
      }
      return redisMockClient;  // Return the client itself for method chaining
    });
  });

  it('should handle the connect event', () => {
    // Simulate the 'connect' event
    redisMockClient.on('connect', () => {
      console.log('Connected to Redis');
    });

    // Check that the connect event listener was set up correctly
    expect(redisMockClient.on).toHaveBeenCalledWith('connect', expect.any(Function));
  });

  it('should handle the error event', () => {
    const errorCallback = jest.fn();

    // Simulate the 'error' event with a mock error
    redisMockClient.on('error', errorCallback);

    // Simulate error handling
    const mockError = new Error('Redis error occurred');
    (redisMockClient.on as jest.Mock).mock.calls
      .find(call => call[0] === 'error')?.[1](mockError); // Invoke the error callback with the mock error

    // Check that the error event listener was set up correctly
    expect(redisMockClient.on).toHaveBeenCalledWith('error', expect.any(Function));

    // Verify that the error callback was called with the mock error
    expect(errorCallback).toHaveBeenCalledWith(mockError);
  });

  it('should throw an error for the get function as it is not implemented', () => {
    // Test that calling the 'get' function throws an error
    expect(() => {
      redisClient.get('someKey');
    }).toThrow('Function not implemented.');
  });

  it('should log errors if Redis fails to connect', async () => {
    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {}); // Mock console.error
    const mockError = new Error('Failed to connect to Redis');
    
    // Mock redisClient.connect to reject with an error
    redisMockClient.connect = jest.fn().mockRejectedValue(mockError);
    
    // Attempt to connect to Redis and handle the error
    await redisClient.connect().catch((err) => {
      expect(consoleErrorSpy).toHaveBeenCalledWith('Failed to connect to Redis:', mockError);
    });
    
    consoleErrorSpy.mockRestore(); // Restore original console.error
  });
    
    
    afterEach(() => {
        jest.clearAllMocks(); // Clear all mocks after each test
    });
});