// import { sendToFlask, fetchFromFlask } from '../services/flaskService';
// import axios from 'axios'; // Add this import
// jest.mock('axios');
// describe('flaskService', () => {
//   it('should send data to Flask and return response data on success', async () => {
//     // Arrange
//     const mockResponse = { data: 'some data' };
//     axios.post = jest.fn().mockResolvedValue(mockResponse);

//     // Act
//     const response = await sendToFlask({});

//     // Assert
//     expect(response).toEqual(mockResponse.data);
//   });

//   it('should throw error when sending data to Flask fails', async () => {
//     // Arrange
//     const mockError = new Error('Failed to send data to Flask');
//     axios.post = jest.fn().mockRejectedValue(mockError);

//     // Act & Assert
//     await expect(sendToFlask({})).rejects.toThrow('Failed to send data to Flask');
//   });

//   it('should fetch data from Flask and return response data on success', async () => {
//     // Arrange
//     const mockResponse = { data: 'some data' };
//     axios.get = jest.fn().mockResolvedValue(mockResponse);

//     // Act
//     const response = await fetchFromFlask();

//     // Assert
//     expect(response).toEqual(mockResponse.data);
//   });

//   it('should throw error when fetching data from Flask fails', async () => {
//     // Arrange
//     const mockError = new Error('Failed to fetch data from Flask');
//     axios.get = jest.fn().mockRejectedValue(mockError);

//     // Act & Assert
//     await expect(fetchFromFlask()).rejects.toThrow('Failed to fetch data from Flask');
//   });
// });
import { sendToFlask, fetchFromFlask } from '../services/flaskService';
import axios from 'axios';

jest.mock('axios');
const mockAxios = axios as jest.Mocked<typeof axios>;

describe('flaskService', () => {
  it('should send data to Flask and return response data on success', async () => {
    const mockResponse = {
      data: 'response data',
      status: 200,
      statusText: 'OK',
      headers: {},
      config: { url: 'http://localhost:5000' }, // Added minimal config with url
    };

    mockAxios.post.mockResolvedValue(mockResponse);

    const result = await sendToFlask({});
    expect(result).toEqual(mockResponse.data);
  });

  it('should throw error when sending data to Flask fails', async () => {
    const mockError = {
      message: 'Network Error',
      response: {
        data: 'Failed to send data to Flask',
        config: { url: 'http://localhost:5000' }, // Added minimal config with url
      },
    };

    mockAxios.post.mockRejectedValue(mockError);

    await expect(sendToFlask({})).rejects.toThrow('Failed to send data to Flask');
  });

  it('should fetch data from Flask and return response data on success', async () => {
    const mockResponse = {
      data: 'response data',
      status: 200,
      statusText: 'OK',
      headers: {},
      config: { url: 'http://localhost:5000' }, // Added minimal config with url
    };

    mockAxios.get.mockResolvedValue(mockResponse);

    const result = await fetchFromFlask();
    expect(result).toEqual(mockResponse.data);
  });

  it('should throw error when fetching data from Flask fails', async () => {
    const mockError = {
      message: 'Network Error',
      response: {
        data: 'Failed to fetch data from Flask',
        config: { url: 'http://localhost:5000' }, // Added minimal config with url
      },
    };

    mockAxios.get.mockRejectedValue(mockError);

    await expect(fetchFromFlask()).rejects.toThrow('Failed to fetch data from Flask');
  });
});
